import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faCalendar, faFolder, faFileAlt, faFileExcel, faFilePowerpoint, faUsers, faComment, faBars, faTimesCircle } from '@fortawesome/free-solid-svg-icons';

const Sidebar = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const links = [
    {
      url: 'https://mail.google.com/',
      icon: faEnvelope,
    },
    {
      url: 'https://calendar.google.com/',
      icon: faCalendar,
    },
    {
      url: 'https://drive.google.com/',
      icon: faFolder,
    },
    {
      url: 'https://docs.google.com/',
      icon: faFileAlt,
    },
    {
      url: 'https://sheets.google.com/',
      icon: faFileExcel,
    },
    {
      url: 'https://slides.google.com/',
      icon: faFilePowerpoint,
    },
    {
      url: 'https://meet.google.com/',
      icon: faUsers,
    },
    {
      url: 'https://chat.google.com/',
      icon: faComment,
    },
  ];

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className={`sidebar-container ${sidebarOpen ? 'open' : ''}`}>
      <div className="sidebar-button" onClick={toggleSidebar}>
        <FontAwesomeIcon icon={sidebarOpen ? faTimesCircle : faBars} />
      </div>
      {sidebarOpen && (
        <ul>
          {links.map((link) => (
            <li key={link.url}>
              <Link
                to={link.url}
                activeClassName="active"
              >
                <FontAwesomeIcon icon={link.icon} />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Sidebar;



